using Blazored.LocalStorage;
using LocalStorage.Services.Models;

namespace LocalStorage.Services;

public class MockAuthService
{
    private readonly AuthService _authService;
    private const string UserDataKeyName = "userData";

    public MockAuthService(AuthService authService)
    {
        _authService = authService;
    }

    /// <summary>
    /// Authenticates user with username and password using mockup data
    /// </summary>
    public async Task<(bool success, string? message, MockUser? user)> AuthenticateAsync(string username, string password)
    {
        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
        {
            return (false, "Username and password are required", null);
        }

        var user = MockAuthData.AuthenticateUser(username, password);
        
        if (user == null)
        {
            return (false, "Invalid username or password", null);
        }

        // Generate a token (in real app, this would come from server)
        string token = $"token_{user.Id}_{Guid.NewGuid()}";
        
        // Store in AuthService
        await _authService.LoginAsync(token, user.Username);
        
        return (true, "Login successful", user);
    }

    /// <summary>
    /// Gets all available mockup users for testing
    /// </summary>
    public List<MockUser> GetAvailableUsers()
    {
        return MockAuthData.Users;
    }

    /// <summary>
    /// Logs out the current user
    /// </summary>
    public async Task LogoutAsync()
    {
        await _authService.LogoutAsync();
    }

    /// <summary>
    /// Checks if user is logged in
    /// </summary>
    public async Task<bool> IsLoggedInAsync()
    {
        return await _authService.IsLoggedInAsync();
    }

    /// <summary>
    /// Gets the current logged-in username
    /// </summary>
    public async Task<string?> GetCurrentUsernameAsync()
    {
        return await _authService.GetUserNameAsync();
    }
}
