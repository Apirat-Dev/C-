namespace LocalStorage.Services.Models;

public class MockUser
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string DisplayName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
}

public static class MockAuthData
{
    public static List<MockUser> Users = new()
    {
        new MockUser
        {
            Id = 1,
            Username = "admin",
            Password = "admin123",
            DisplayName = "Administrator",
            Email = "admin@example.com"
        },
        new MockUser
        {
            Id = 2,
            Username = "user",
            Password = "user123",
            DisplayName = "John Doe",
            Email = "john@example.com"
        },
        new MockUser
        {
            Id = 3,
            Username = "test",
            Password = "test123",
            DisplayName = "Test User",
            Email = "test@example.com"
        },
        new MockUser
        {
            Id = 4,
            Username = "demo",
            Password = "demo123",
            DisplayName = "Demo Account",
            Email = "demo@example.com"
        }
    };

    public static MockUser? AuthenticateUser(string username, string password)
    {
        return Users.FirstOrDefault(u => 
            u.Username == username && u.Password == password);
    }

    public static MockUser? GetUserByUsername(string username)
    {
        return Users.FirstOrDefault(u => u.Username == username);
    }
}
