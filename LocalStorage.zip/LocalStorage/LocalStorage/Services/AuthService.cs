using Blazored.LocalStorage;

namespace LocalStorage.Services;

public class AuthService
{
    private readonly ILocalStorageService _localStorageService;
    private const string AuthKeyName = "authToken";
    private const string UserKeyName = "currentUser";

    public AuthService(ILocalStorageService localStorageService)
    {
        _localStorageService = localStorageService;
    }

    /// <summary>
    /// Checks if user is logged in by verifying if auth token exists in localStorage
    /// </summary>
    public async Task<bool> IsLoggedInAsync()
    {
        try
        {
            var token = await _localStorageService.GetItemAsync<string>(AuthKeyName);
            return !string.IsNullOrEmpty(token);
        }
        catch (Exception)
        {
            return false;
        }
    }

    /// <summary>
    /// Logs in a user by storing auth token and user info in localStorage
    /// </summary>
    public async Task LoginAsync(string token, string? userName = null)
    {
        await _localStorageService.SetItemAsync(AuthKeyName, token);
        if (!string.IsNullOrEmpty(userName))
        {
            await _localStorageService.SetItemAsync(UserKeyName, userName);
        }
    }

    /// <summary>
    /// Logs out a user by removing auth token and user info from localStorage
    /// </summary>
    public async Task LogoutAsync()
    {
        await _localStorageService.RemoveItemAsync(AuthKeyName);
        await _localStorageService.RemoveItemAsync(UserKeyName);
    }

    /// <summary>
    /// Gets the stored auth token from localStorage
    /// </summary>
    public async Task<string?> GetTokenAsync()
    {
        try
        {
            return await _localStorageService.GetItemAsync<string>(AuthKeyName);
        }
        catch (Exception)
        {
            return null;
        }
    }

    /// <summary>
    /// Gets the stored username from localStorage
    /// </summary>
    public async Task<string?> GetUserNameAsync()
    {
        try
        {
            return await _localStorageService.GetItemAsync<string>(UserKeyName);
        }
        catch (Exception)
        {
            return null;
        }
    }

    /// <summary>
    /// Clears all stored data from localStorage
    /// </summary>
    public async Task ClearAsync()
    {
        await _localStorageService.ClearAsync();
    }
}
