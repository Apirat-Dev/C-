namespace BlazorApp1.Services
{
    /// <summary>
    /// Authentication service with AD mockup users
    /// </summary>
    public class AuthenticationService
    {
        // Mock AD users for authentication
        private static readonly Dictionary<string, string> MockADUsers = new()
        {
            { "admin", "admin123" },
            { "user", "user123" },
            { "john.doe", "password" }
        };

        private User? _currentUser;
        private readonly object _lockObject = new object();

        public User? CurrentUser
        {
            get
            {
                lock (_lockObject)
                {
                    return _currentUser;
                }
            }
            private set
            {
                lock (_lockObject)
                {
                    _currentUser = value;
                }
            }
        }

        public event Func<Task>? OnAuthenticationChanged;

        public async Task<bool> LoginAsync(string username, string password)
        {
            // Simulate API call delay
            await Task.Delay(500);

            if (MockADUsers.TryGetValue(username, out var storedPassword))
            {
                if (storedPassword == password)
                {
                    CurrentUser = new User
                    {
                        Username = username,
                        DisplayName = $"User: {username}",
                        Email = $"{username}@company.com",
                        IsAuthenticated = true
                    };
                    await NotifyAuthenticationChangedAsync();
                    return true;
                }
            }

            return false;
        }

        public async Task LogoutAsync()
        {
            CurrentUser = null;
            await Task.Delay(100);
            await NotifyAuthenticationChangedAsync();
        }

        public bool IsAuthenticated => CurrentUser?.IsAuthenticated ?? false;

        private async Task NotifyAuthenticationChangedAsync()
        {
            if (OnAuthenticationChanged != null)
            {
                await OnAuthenticationChanged.Invoke();
            }
        }
    }

    public class User
    {
        public string Username { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public bool IsAuthenticated { get; set; }
    }
}
