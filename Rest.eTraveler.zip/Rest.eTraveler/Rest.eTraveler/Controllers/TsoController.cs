﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Rest.eTraveler.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TsoController : ControllerBase
    {
        [HttpGet("GetTsoHeader")]
        public IActionResult GetTsoHeader()
        {
            return Ok("Hello from TsoController");
        }
        [HttpGet("GetTsoHardwareSetup")]
        public IActionResult GetTsoHardwareSetup()
        {
            return Ok("Hello from TsoController");
        }
        [HttpGet("GetTsoSetupProgram")]
        public IActionResult GetTsoSetupProgram()
        {
            return Ok("Hello from TsoController");
        }
    }
}
